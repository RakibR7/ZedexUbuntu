const express = require('express');
const multer = require('multer');
const path = require('path');  // Add this line to import the path module

// Set up storage engine
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');  // Destination folder
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));  // Filename format
    }
});

// Initialize upload variable
const upload = multer({ storage: storage });

const app = express();

// Route for file upload
app.post('/upload', upload.single('file'), (req, res) => {
    console.log(req.file);  // Log file metadata
    res.send('File uploaded successfully.');
});

// Serve a simple form for file upload (for testing)
app.get('/', (req, res) => {
    res.send('<form method="post" enctype="multipart/form-data" action="/upload"><input type="file" name="file"/><input type="submit"/></form>');
});

// Start the server
app.listen(3000, () => {
    console.log('Server started on port 3000');
});
