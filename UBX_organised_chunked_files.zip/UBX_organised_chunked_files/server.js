const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const sf = require('split-file');

// Set up the storage engine for Multer
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');  // Destination folder
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));  // Filename format
    }
});

const upload = multer({ storage: storage });
const app = express();

// Route for file upload
app.post('/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('No file uploaded.');
    }

    // Split the file into 25MB chunks
    sf.splitFileBySize(req.file.path, 25 * 1024 * 1024)  // 25MB in bytes
        .then((fileParts) => {
            const chunkDir = 'chunked_files';
            if (!fs.existsSync(chunkDir)){
                fs.mkdirSync(chunkDir);
            }

            fileParts.forEach((part, index) => {
                const newFileName = `${chunkDir}/${path.basename(req.file.originalname)}_chunk_${index}`;
                fs.renameSync(part, newFileName);
            });

            console.log('File has been split and moved to chunks directory');
            res.send('File uploaded, chunked, and organized successfully.');
        })
        .catch((err) => {
            console.error('Error splitting file:', err);
            res.status(500).send('Error in file chunking.');
        });
});

// Serve a simple form for file upload (for testing)
app.get('/', (req, res) => {
    res.send('<form method="post" enctype="multipart/form-data" action="/upload"><input type="file" name="file"/><input type="submit"/></form>');
});

// Start the server
app.listen(3000, () => {
    console.log('Server started on port 3000');
});
