#!/bin/bash

# Check if a file path is provided
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <file_path>"
    exit 1
fi

file_path=$1
chunk_size=25M  # 25 MB

# Split the file into 25MB chunks
split -b $chunk_size -d $file_path "${file_path}_chunk_"

echo "Chunking complete."
